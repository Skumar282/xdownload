package com.example

import com.example.data.model.DownloadStatus
import com.example.data.model.MediaType
import com.example.data.model.MediaVariant
import com.example.data.model.ResolvedMedia
import com.example.download.DownloadResult
import com.example.resolver.ResolutionError
import com.example.resolver.ResolutionResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadEngineLogicTest {

    @Test
    fun testDuplicateDetectionLogic() {
        val completedPostIds = setOf("1844781290123456789", "998877665544332211")

        fun isDuplicate(postId: String, preventDuplicates: Boolean): Boolean {
            if (!preventDuplicates) return false
            return completedPostIds.contains(postId)
        }

        // With preventDuplicates = true
        assertTrue(isDuplicate("1844781290123456789", preventDuplicates = true))
        assertFalse(isDuplicate("112233445566778899", preventDuplicates = true))

        // With preventDuplicates = false (user allows re-downloading)
        assertFalse(isDuplicate("1844781290123456789", preventDuplicates = false))
    }

    @Test
    fun testFailedDownloadResults() {
        val networkError = DownloadResult.Error(
            message = "Network connection timeout",
            isNetworkError = true
        )
        assertTrue(networkError.isNetworkError)
        assertEquals("Network connection timeout", networkError.message)

        val storageError = DownloadResult.Error(
            message = "Storage is full. Please free up space on your device.",
            isNetworkError = false
        )
        assertFalse(storageError.isNetworkError)
        assertTrue(storageError.message.contains("Storage is full"))
    }

    @Test
    fun testFileNameGeneration() {
        fun generateFileName(author: String?, postId: String, mediaType: MediaType, mimeType: String): String {
            val extension = when (mediaType) {
                MediaType.VIDEO -> "mp4"
                MediaType.GIF -> "mp4"
                MediaType.IMAGE -> if (mimeType.contains("png")) "png" else "jpg"
            }
            val authorTag = author?.takeIf { it.isNotBlank() } ?: "post"
            return "x_${authorTag}_$postId.$extension"
        }

        assertEquals(
            "x_nasa_12345.mp4",
            generateFileName("nasa", "12345", MediaType.VIDEO, "video/mp4")
        )
        assertEquals(
            "x_photographer_67890.jpg",
            generateFileName("photographer", "67890", MediaType.IMAGE, "image/jpeg")
        )
        assertEquals(
            "x_artist_11111.png",
            generateFileName("artist", "11111", MediaType.IMAGE, "image/png")
        )
        assertEquals(
            "x_post_99999.mp4",
            generateFileName(null, "99999", MediaType.GIF, "video/mp4")
        )
    }

    @Test
    fun testResolutionErrorHonesty() {
        // Never claim success for private/login-required content
        val privateError: ResolutionResult = ResolutionResult.Error(
            ResolutionError.LOGIN_REQUIRED_OR_PRIVATE,
            "This post is private or requires authentication to view."
        )
        assertFalse(privateError is ResolutionResult.Success)
        assertEquals(ResolutionError.LOGIN_REQUIRED_OR_PRIVATE, (privateError as ResolutionResult.Error).errorType)

        // Post not found / deleted
        val notFoundError: ResolutionResult = ResolutionResult.Error(
            ResolutionError.POST_NOT_FOUND,
            "Post #123 could not be found or has been deleted."
        )
        assertFalse(notFoundError is ResolutionResult.Success)

        // No media in text-only post
        val noMediaError: ResolutionResult = ResolutionResult.Error(
            ResolutionError.NO_MEDIA_FOUND,
            "No downloadable photo or video found in this post."
        )
        assertFalse(noMediaError is ResolutionResult.Success)
    }
}
